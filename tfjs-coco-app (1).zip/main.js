import * as cocoSsd from '@tensorflow-models/coco-ssd';
import '@tensorflow/tfjs';

const video = document.getElementById('webcam');
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');

async function setupWebcam() {
  const stream = await navigator.mediaDevices.getUserMedia({
    video: true,
  });
  video.srcObject = stream;
  return new Promise((resolve) => {
    video.onloadedmetadata = () => {
      resolve(video);
    };
  });
}

async function runDetection() {
  await setupWebcam();
  const model = await cocoSsd.load();
  console.log('Model loaded.');

  const detectFrame = async () => {
    const predictions = await model.detect(video);
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    predictions.forEach((prediction) => {
      ctx.strokeStyle = 'red';
      ctx.lineWidth = 2;
      ctx.strokeRect(...prediction.bbox);
      ctx.font = '16px Arial';
      ctx.fillStyle = 'red';
      ctx.fillText(
        `${prediction.class} (${Math.round(prediction.score * 100)}%)`,
        prediction.bbox[0],
        prediction.bbox[1] > 10 ? prediction.bbox[1] - 5 : 10
      );
    });

    requestAnimationFrame(detectFrame);
  };

  detectFrame();
}

runDetection();
